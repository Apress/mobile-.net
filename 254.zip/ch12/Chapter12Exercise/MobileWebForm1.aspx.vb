Public Class MobileWebForm1
    Inherits System.Web.UI.MobileControls.MobilePage
    Protected WithEvents TextBox1 As System.Web.UI.MobileControls.TextBox
    Protected WithEvents Command1 As System.Web.UI.MobileControls.Command
    Protected WithEvents RegularExpressionValidator1 As System.Web.UI.MobileControls.RegularExpressionValidator
    Protected WithEvents Form2 As System.Web.UI.MobileControls.Form
    Protected WithEvents Label1 As System.Web.UI.MobileControls.Label
    Protected WithEvents Form1 As System.Web.UI.MobileControls.Form

#Region " Web Form Designer Generated Code "
    
    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    
    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub
    
#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub Command1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Command1.Click

        Dim price As String
        Dim ws As localhost.Service1 = New localhost.Service1()

        If Page.IsValid Then

            Me.ActiveForm = Form2
            Label1.Text = ws.getQuote(TextBox1.Text)

        End If

    End Sub
End Class
