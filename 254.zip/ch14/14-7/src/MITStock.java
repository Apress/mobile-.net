import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.io.*;
import javax.microedition.io.*;

import org.kxml.*;
import org.kxml.io.*;
import org.kxml.kdom.*;
import org.kxml.parser.*;

public class MITStock extends MIDlet implements CommandListener
{
   static final String serviceNamespace = "http://pocketdba.com/webservices/";

   Form mainForm = new Form("Fergie Stock");
   TextField fromField = new TextField("Symbol :", "ALGX", 4, TextField.ANY);
   StringItem resultItem = new StringItem("", "");
   Command getCommand = new Command("Get", Command.SCREEN, 1);

   public MITStock()
   {
      mainForm.append (fromField);
      mainForm.append (resultItem);
      mainForm.addCommand (getCommand);
      mainForm.setCommandListener (this);
   }

   public void startApp()
   {
      Display.getDisplay (this).setCurrent (mainForm);
   }


   public void pauseApp()
   {
   }

   public void destroyApp(boolean unconditional)
   {
   }

   public void commandAction (Command c, Displayable d)
   {
      try
      {
         String from = fromField.getString();     

         HttpConnection connection = (HttpConnection) Connector.open("http://YOURHOSTIP/MobileStockQuoter/MobileWebForm1.aspx?symbol=" + from, Connector.READ_WRITE);

         connection.setRequestMethod (HttpConnection.GET);
         connection.setRequestProperty ("User-Agent", "J2ME-compliant device");

         InputStream is = ((StreamConnection) connection).openInputStream();
         int buffSize=200;
         byte[] buff = new byte[buffSize];
         ByteArrayOutputStream bytebuff=new ByteArrayOutputStream(buffSize);

         int eof=0;
         while (eof!=-1)
         {
            eof=is.read(buff);
            if (eof!=-1)
            {
               bytebuff.write(buff,0,eof);
            }
         }

         is.close();

         String response = new String(bytebuff.toByteArray());
         System.out.println (response);

         Reader reader = new InputStreamReader(new ByteArrayInputStream(bytebuff.toByteArray()));
         XmlParser parser = new XmlParser(reader);
         Document doc = new Document();
         doc.parse(parser);
         Element root = doc.getRootElement();
         Element price = root.getElement(1);
         resultItem.setLabel("amount :");
         resultItem.setText(price.getText());
     
         connection.close();
      }
      catch (Exception e)
      {
         resultItem.setLabel("Error:");
         resultItem.setText(e.toString());
      }
   }
}