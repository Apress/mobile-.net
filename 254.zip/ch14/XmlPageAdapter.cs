using System;
using System.Collections;
using System.Collections.Specialized;
using System.Diagnostics;
using System.IO;
using System.Web;
using System.Web.Mobile;
using System.Web.UI;
using System.Web.UI.MobileControls;
using System.Web.UI.MobileControls.Adapters;

namespace PocketDBAAdapter  

{

    public class XmlPageAdapter : WmlPageAdapter
    {
        private static String _headerBegin = "<?xml version='1.0'";
        private static String _headerEncoding = " encoding = '{0}'";
        private static String _headerEnd = "?>\r\n";
        private IList _renderableForms;        

        public static new bool DeviceQualifies(HttpContext context)
        {
           String bro = context.Request.Browser.Browser.ToString();
           bool qualifies = (bro == "J2ME");
           return qualifies;
        }

        private void RenderXmlHeader(HtmlTextWriter writer)
        {
           writer.Write(_headerBegin);
           String charset = Page.Response.Charset;
           if (charset != null && charset.Length > 0 && String.Compare(charset, "utf-8", true) != 0)
              writer.Write(String.Format(_headerEncoding, charset));
           writer.Write(_headerEnd);
        }

        public override void Render(WmlMobileTextWriter writer)
        {
           writer.BeginResponse();
           writer.BeginFile(Page.Request.Url.ToString(), "text/xml", Page.Response.Charset);

           RenderXmlHeader(writer);

           _renderableForms = Page.ActiveForm.GetLinkedForms(OptimumPageWeight);
           Debug.Assert(_renderableForms != null, "_renderableForms is null");

           foreach (Form form in _renderableForms)
              form.RenderControl(writer);

           writer.EndFile();
           writer.EndResponse();
        }
    }
}

