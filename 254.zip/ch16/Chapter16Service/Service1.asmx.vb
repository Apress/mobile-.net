Imports System.Web.Services
Imports System.Data.SqlClient


<WebService(Namespace:="http://pocketdba.com/webservices/")> _
Public Class Service1
    Inherits System.Web.Services.WebService

#Region " Web Services Designer Generated Code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Web Services Designer.
        InitializeComponent()

        'Add your own initialization code after the InitializeComponent() call

    End Sub

    'Required by the Web Services Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Web Services Designer
    'It can be modified using the Web Services Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        components = New System.ComponentModel.Container()
    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        'CODEGEN: This procedure is required by the Web Services Designer
        'Do not modify it using the code editor.
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

#End Region


    <WebMethod()> Public Function getBands() As DataSet

        Dim strCnnctn As String
        Dim sqlCnnctn As SqlConnection

        strCnnctn = "Initial Catalog=GrocerToGo;Data Source=YOURCOMPUTER\NETSDK;user id=sa;"
        sqlCnnctn = New SqlConnection(strCnnctn)
        sqlCnnctn.Open()

        Dim strCmmnd As String
        Dim sqlCmmnd As SqlCommand

        strCmmnd = "select * from bands"
        sqlCmmnd = New SqlCommand(strCmmnd, sqlCnnctn)

        Dim sqlDA As SqlDataAdapter
        sqlDA = New SqlDataAdapter(sqlCmmnd)

        Dim sqlDS As DataSet
        sqlDS = New DataSet()
        sqlDA.Fill(sqlDS)

        sqlCnnctn.Close()

        getBands = sqlDS

    End Function

    <WebMethod()> Public Function updateBands(ByVal ds As DataSet) As Boolean

        Try

            Dim strCnnctn As String
            Dim sqlCnnctn As SqlConnection

            strCnnctn = "Initial Catalog=GrocerToGo;Data Source=YOURCOMPUTER\NETSDK;user id=sa;"
            sqlCnnctn = New SqlConnection(strCnnctn)
            sqlCnnctn.Open()

            Dim strCmmnd As String
            Dim sqlCmmnd As SqlCommand

            strCmmnd = "select * from bands"
            sqlCmmnd = New SqlCommand(strCmmnd, sqlCnnctn)

            Dim sqlDA As SqlDataAdapter
            sqlDA = New SqlDataAdapter(sqlCmmnd)

            Dim scb As SqlCommandBuilder = New SqlCommandBuilder(sqlDA)
            sqlDA.Update(ds)
            sqlCnnctn.Close()

        Catch problem As Exception

            updateBands = False
            Exit Function

        End Try

        updateBands = True

    End Function

End Class
