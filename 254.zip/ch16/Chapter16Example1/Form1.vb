Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnPrevious As System.Windows.Forms.Button
    Friend WithEvents btnNew As System.Windows.Forms.Button
    Friend WithEvents btnNext As System.Windows.Forms.Button
    Friend WithEvents btnQuit As System.Windows.Forms.Button
    Friend WithEvents txtGuitar As System.Windows.Forms.TextBox
    Friend WithEvents txtKeyboards As System.Windows.Forms.TextBox
    Friend WithEvents txtBass As System.Windows.Forms.TextBox
    Friend WithEvents txtDrums As System.Windows.Forms.TextBox
    Friend WithEvents txtVocals As System.Windows.Forms.TextBox

    Dim ds As DataSet
    Dim dt As DataTable
    Dim dr As DataRow
    Dim isNew As Boolean
    Dim rn As Integer

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnPrevious = New System.Windows.Forms.Button()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.btnQuit = New System.Windows.Forms.Button()
        Me.txtGuitar = New System.Windows.Forms.TextBox()
        Me.txtKeyboards = New System.Windows.Forms.TextBox()
        Me.txtBass = New System.Windows.Forms.TextBox()
        Me.txtDrums = New System.Windows.Forms.TextBox()
        Me.txtVocals = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.Label1.Location = New System.Drawing.Point(32, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Guitar"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.Label2.Location = New System.Drawing.Point(32, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Keyboards"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.Label3.Location = New System.Drawing.Point(56, 112)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 23)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Bass"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.Label4.Location = New System.Drawing.Point(56, 152)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 23)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Drums"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.Label5.Location = New System.Drawing.Point(40, 192)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 23)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Vocals"
        '
        'btnPrevious
        '
        Me.btnPrevious.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.btnPrevious.Image = Nothing
        Me.btnPrevious.Location = New System.Drawing.Point(24, 256)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.Size = New System.Drawing.Size(75, 23)
        Me.btnPrevious.TabIndex = 5
        Me.btnPrevious.Text = "Previous"
        '
        'btnNew
        '
        Me.btnNew.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.btnNew.Image = Nothing
        Me.btnNew.Location = New System.Drawing.Point(112, 256)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(75, 23)
        Me.btnNew.TabIndex = 6
        Me.btnNew.Text = "New"
        '
        'btnNext
        '
        Me.btnNext.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.btnNext.Image = Nothing
        Me.btnNext.Location = New System.Drawing.Point(200, 256)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(75, 23)
        Me.btnNext.TabIndex = 7
        Me.btnNext.Text = "Next"
        '
        'btnQuit
        '
        Me.btnQuit.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.btnQuit.Image = Nothing
        Me.btnQuit.Location = New System.Drawing.Point(112, 296)
        Me.btnQuit.Name = "btnQuit"
        Me.btnQuit.Size = New System.Drawing.Size(75, 23)
        Me.btnQuit.TabIndex = 8
        Me.btnQuit.Text = "Quit"
        '
        'txtGuitar
        '
        Me.txtGuitar.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtGuitar.Location = New System.Drawing.Point(168, 24)
        Me.txtGuitar.Name = "txtGuitar"
        Me.txtGuitar.Size = New System.Drawing.Size(100, 20)
        Me.txtGuitar.TabIndex = 9
        Me.txtGuitar.Text = ""
        '
        'txtKeyboards
        '
        Me.txtKeyboards.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtKeyboards.Location = New System.Drawing.Point(168, 72)
        Me.txtKeyboards.Name = "txtKeyboards"
        Me.txtKeyboards.Size = New System.Drawing.Size(100, 20)
        Me.txtKeyboards.TabIndex = 10
        Me.txtKeyboards.Text = ""
        '
        'txtBass
        '
        Me.txtBass.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtBass.Location = New System.Drawing.Point(176, 112)
        Me.txtBass.Name = "txtBass"
        Me.txtBass.Size = New System.Drawing.Size(100, 20)
        Me.txtBass.TabIndex = 11
        Me.txtBass.Text = ""
        '
        'txtDrums
        '
        Me.txtDrums.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtDrums.Location = New System.Drawing.Point(176, 152)
        Me.txtDrums.Name = "txtDrums"
        Me.txtDrums.Size = New System.Drawing.Size(100, 20)
        Me.txtDrums.TabIndex = 12
        Me.txtDrums.Text = ""
        '
        'txtVocals
        '
        Me.txtVocals.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtVocals.Location = New System.Drawing.Point(168, 192)
        Me.txtVocals.Name = "txtVocals"
        Me.txtVocals.Size = New System.Drawing.Size(100, 20)
        Me.txtVocals.TabIndex = 13
        Me.txtVocals.Text = ""
        '
        'Form1
        '
        Me.ClientSize = New System.Drawing.Size(292, 374)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtVocals, Me.txtDrums, Me.txtBass, Me.txtKeyboards, Me.txtGuitar, Me.btnQuit, Me.btnNext, Me.btnNew, Me.btnPrevious, Me.Label5, Me.Label4, Me.Label3, Me.Label2, Me.Label1})
        Me.Name = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Public Shared Sub Main()
        Application.Run(New Form1())
    End Sub
#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ds = New DataSet("Progressive Rock")

        Try

            ds.ReadXml("PR.xml")
            dt = ds.Tables("Bands")
            dr = dt.Rows(0)
            txtGuitar.Text = dr("Guitar")
            txtKeyboards.Text = dr("Keyboards")
            txtBass.Text = dr("Bass")
            txtDrums.Text = dr("Drums")
            txtVocals.Text = dr("Vocals")

        Catch problems As Exception

            dt = New DataTable("Bands")

            dt.Columns.Add("Guitar", System.Type.GetType("System.String"))
            dt.Columns.Add("Keyboards", System.Type.GetType("System.String"))
            dt.Columns.Add("Bass", System.Type.GetType("System.String"))
            dt.Columns.Add("Drums", System.Type.GetType("System.String"))
            dt.Columns.Add("Vocals", System.Type.GetType("System.String"))

            ds.Tables.Add(dt)
            dr = dt.NewRow()
            isNew = True

        End Try

        rn = 0

    End Sub

    Private Sub btnNew_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNew.Click

        saveCurrentRow()
        dr = dt.NewRow()
        rn = rn + 1
        isNew = True

        txtGuitar.Text = ""
        txtKeyboards.Text = ""
        txtBass.Text = ""
        txtDrums.Text = ""
        txtVocals.Text = ""

    End Sub

    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click

        Try

            saveCurrentRow()
            rn = rn + 1
            dr = dt.Rows(rn)

            txtGuitar.Text = dr("Guitar")
            txtKeyboards.Text = dr("Keyboards")
            txtBass.Text = dr("Bass")
            txtDrums.Text = dr("Drums")
            txtVocals.Text = dr("Vocals")

        Catch problem As Exception

            rn = rn - 1

        End Try

    End Sub

    Private Sub btnPrevious_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPrevious.Click

        Try

            saveCurrentRow()
            rn = rn - 1
            dr = dt.Rows(rn)

            txtGuitar.Text = dr("Guitar")
            txtKeyboards.Text = dr("Keyboards")
            txtBass.Text = dr("Bass")
            txtDrums.Text = dr("Drums")
            txtVocals.Text = dr("Vocals")

        Catch problem As Exception

            rn = rn - 1

        End Try

    End Sub

    Private Sub saveCurrentRow()

        dr("Guitar") = txtGuitar.Text
        dr("Keyboards") = txtKeyboards.Text
        dr("Bass") = txtBass.Text
        dr("Drums") = txtDrums.Text
        dr("Vocals") = txtVocals.Text

        Try
            dt.Rows.Add(dr)
        Catch problem As Exception
        End Try

    End Sub

    Private Sub btnQuit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnQuit.Click

        saveCurrentRow()
        ds.WriteXml("PR.xml")
        Application.Exit()

    End Sub
End Class
