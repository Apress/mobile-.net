Imports System.Net
Imports System.Text.RegularExpressions

Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents RegularExpressionValidator1 As System.Web.UI.WebControls.RegularExpressionValidator

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If Page.IsValid Then
            Dim hwreq As HttpWebRequest
            Dim hwres As HttpWebResponse
            Dim inStream As System.IO.Stream
            Dim strResponse As String

            hwreq = CType(WebRequest.Create("http://finance.lycos.com/" & _
                "home/stocks/quotes.asp?symbols=" & TextBox1.Text), HttpWebRequest)
            hwres = CType(hwreq.GetResponse(), HttpWebResponse)
            inStream = hwres.GetResponseStream()

            Try
                Do While True
                    strResponse = strResponse & Chr(inStream.ReadByte())
                Loop
            Catch ex As Exception
            End Try

            inStream.Close()

            Dim rgExp As Regex
            Dim m As Match
            Dim btPrice As Byte()

            m = rgExp.Match(strResponse, "\d+\.\d+", RegexOptions.Singleline)

            If m.Success Then
                Label1.Text = " . . . is trading at " & m.Value()
            Else
                Label1.Text = " . . . cannot be found!"
            End If

        Else
                Label1.Text = ""
        End If

    End Sub
End Class
