Imports System.Threading

Public Class Form1
    Inherits System.Windows.Forms.Form
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents txtMessages As System.Windows.Forms.TextBox

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        MyBase.Dispose(disposing)
    End Sub

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Private Sub InitializeComponent()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.txtMessages = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnStart
        '
        Me.btnStart.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.btnStart.Image = Nothing
        Me.btnStart.Location = New System.Drawing.Point(16, 176)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(128, 40)
        Me.btnStart.TabIndex = 0
        Me.btnStart.Text = "Start Listening"
        '
        'txtMessages
        '
        Me.txtMessages.Font = New System.Drawing.Font("Tahoma", 8.0!)
        Me.txtMessages.Location = New System.Drawing.Point(16, 8)
        Me.txtMessages.Multiline = True
        Me.txtMessages.Name = "txtMessages"
        Me.txtMessages.Size = New System.Drawing.Size(120, 160)
        Me.txtMessages.TabIndex = 1
        Me.txtMessages.Text = "TextBox1"
        '
        'Form1
        '
        Me.ClientSize = New System.Drawing.Size(152, 222)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtMessages, Me.btnStart})
        Me.Name = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Public Shared Sub Main()
        Application.Run(New Form1())
    End Sub
#End Region

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click

        Dim lsnr As Listener = New Listener()
        lsnr.setMessageControl(txtMessages)
        Dim tsLsnr As ThreadStart = New ThreadStart(AddressOf lsnr.run)
        Dim thrLsnr As Thread = New Thread(tsLsnr)
        Dim app As Application
        thrLsnr.Start()

        btnStart.Enabled = False

    End Sub
End Class
