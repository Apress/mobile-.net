Imports System.Net.Sockets
Imports System.Text

Public Class Listener

    Dim txtMessages As System.Windows.Forms.TextBox

    Public Sub run()

        Dim tcpl As TcpListener = New TcpListener(1993)
        Dim enc As ASCIIEncoding = New ASCIIEncoding()
        Dim app As Application

        tcpl.Start()

        Do Until False

            Dim sckt As Socket = tcpl.AcceptSocket
            Dim btChar(0) As Byte

            sckt.Receive(btChar, 1, 0)

            Try
                txtMessages.Text = txtMessages.Text & Now & " - "
                Do Until btChar(0) = 13
                    app.DoEvents()
                    txtMessages.Text = txtMessages.Text & _
                    enc.GetString(btChar, 0, btChar.Length)
                    sckt.Receive(btChar, 1, 0)
                Loop
                txtMessages.Text = txtMessages.Text & vbCrLf & vbCrLf
            Catch problem As Exception
            End Try

            sckt.Close()

        Loop

    End Sub

    Public Sub setMessageControl(ByVal c As System.Windows.Forms.TextBox)
        txtMessages = c
    End Sub

End Class
