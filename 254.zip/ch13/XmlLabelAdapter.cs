using System;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.MobileControls;
using System.Web.UI.MobileControls.Adapters;

namespace PocketDBAAdapter  

{

    public class XmlLabelAdapter : WmlLabelAdapter
    {
        public static bool DeviceQualifies(HttpContext context)
        {
           String bro = context.Request.Browser.Browser.ToString();
           bool qualifies = (bro == "J2ME");
           return qualifies;
        }
    }

}

