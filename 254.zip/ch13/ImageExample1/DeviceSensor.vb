Namespace PocketDBA

    Public Class DeviceSensor

        Public Shared Function determineProxyUsage(ByVal caps As System.Web.Mobile.MobileCapabilities, ByVal garbage As String) As Boolean

            Dim bro As String = caps.Browser.ToString

            If caps.HasCapability("isPocketIE", "") Then
                Stop
                determineProxyUsage = False
            ElseIf caps.HasCapability("isUP4x", "") Then
                Stop
                determineProxyUsage = False
            ElseIf caps.HasCapability("isHTML32", "") Then
                Stop
                determineProxyUsage = True
            Else
                Stop
                determineProxyUsage = False
            End If

        End Function

    End Class

End Namespace

