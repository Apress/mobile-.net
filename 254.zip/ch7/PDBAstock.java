import java.io.*;

import javax.microedition.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class PDBAstock extends MIDlet implements CommandListener
{

   private Display dsp;
   private Command cmdExit, cmdLookup;
   private TextBox txtSymbol;

   public PDBAstock()
   {
      cmdExit = new Command("Exit", Command.EXIT, 0);
      cmdLookup = new Command("Lookup", Command.SCREEN, 0);

      txtSymbol = new TextBox("Stock Symbol", "", 32, 0);
      txtSymbol.addCommand(cmdExit);
      txtSymbol.addCommand(cmdLookup);
      txtSymbol.setCommandListener(this);
   }

   public void startApp()
   {
      dsp = Display.getDisplay(this);
      dsp.setCurrent(txtSymbol);
   }

   public void pauseApp()
   {
   }

   public void destroyApp(boolean unconditional)
   {
   }

   public void commandAction(Command c, Displayable s)
   {
      if (c == cmdExit)
      {
         destroyApp(false);
         notifyDestroyed();
      }
      else if (c == cmdLookup)
      {
         String quote = "", strURL = "http://localhost/stockrsp.asp?symbol=";
         InputStream in = null;
         OutputStream out = null;

         byte[] bf = new byte[512];
         int index = 0;

         try
         {
            HttpConnection cn = (HttpConnection)Connector.open(strURL + txtSymbol.getString());
            cn.setRequestProperty("User-Agent", "PDBAJ2ME");
            out = cn.openOutputStream();
            out.flush();

            in = cn.openInputStream();

            int i;

            while ((i = in.read()) != -1)
            {
               if (i == 60)
                  break;

               bf[index++] = (byte) i;
               quote = new String(bf, 0, index);
            }
         }
         catch (Exception e)
         {
            System.out.println(e);
         }

         Alert answer = new Alert("Your Quote", quote, null, null);
         answer.setTimeout(Alert.FOREVER);
         dsp.setCurrent(answer, txtSymbol);
      }
   }
}