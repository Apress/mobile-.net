import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import java.io.*;
import javax.microedition.io.*;

import org.ksoap.*;
import org.kxml.*;
import org.kxml.io.*;
import org.kxml.parser.*;

public class FergieStock extends MIDlet implements CommandListener
{
   static final String serviceNamespace = "http://pocketdba.com/webservices/";

   Form mainForm = new Form("Fergie Stock");
   TextField fromField = new TextField("Symbol :", "ALGX", 4, TextField.ANY);
   StringItem resultItem = new StringItem("", "");
   Command getCommand = new Command("Get", Command.SCREEN, 1);

   public FergieStock()
   {
      mainForm.append (fromField);
      mainForm.append (resultItem);
      mainForm.addCommand (getCommand);
      mainForm.setCommandListener (this);
   }

   public void startApp()
   {
      Display.getDisplay (this).setCurrent (mainForm);
   }


   public void pauseApp()
   {
   }

   public void destroyApp(boolean unconditional)
   {
   }

   public void commandAction (Command c, Displayable d)
   {
      try
      {
         String from = fromField.getString();

         ByteArrayOutputStream bos = new ByteArrayOutputStream();

         SoapObject request = new SoapObject(serviceNamespace, "getQuote");

         request.addProperty("symbol", fromField.getString());

         ClassMap classMap = new ClassMap();
         classMap.prefixMap = new PrefixMap(classMap.prefixMap, "tns", "http://pocketdba.com/webservices/");

         SoapEnvelope envelope = new SoapEnvelope (classMap);
         envelope.setBody(request);

         XmlWriter xw = new XmlWriter (new OutputStreamWriter (bos));
         envelope.write (xw);
         xw.flush();

         byte [] data = bos.toByteArray();

         System.out.println(new String (data));

         HttpConnection connection = (HttpConnection) Connector.open("http://localhost/Chapter11One/Service1.asmx", Connector.READ_WRITE);

         connection.setRequestMethod (HttpConnection.POST);
         connection.setRequestProperty ("Content-Type", "text/xml");
         connection.setRequestProperty ("Connection", "close");
         connection.setRequestProperty ("Content-Length", ""+data.length);
         connection.setRequestProperty ("SOAPAction", "\"http://pocketdba.com/webservices/getQuote\"");

         OutputStream os = connection.openOutputStream();
         os.write (data);
         os.flush ();

         InputStream is = ((StreamConnection) connection).openInputStream();
         int buffSize=200;
         byte[] buff = new byte[buffSize];
         ByteArrayOutputStream bytebuff=new ByteArrayOutputStream(buffSize);

         int eof=0;
         while (eof!=-1)
         {
            eof=is.read(buff);
            if (eof!=-1)
            {
               bytebuff.write(buff,0,eof);
            }
         }

         is.close();

         String response = new String(bytebuff.toByteArray());
         System.out.println (response);

         Reader reader = new InputStreamReader(new ByteArrayInputStream(bytebuff.toByteArray()));         
         XmlParser parser = new XmlParser (reader);

         SoapEnvelope resultEnvelope = new SoapEnvelope();
         resultEnvelope.parse (parser);

         resultItem.setLabel ("amount :");
         String result = (String)resultEnvelope.getResult();
         result = result.substring(0,result.indexOf(".")+3);
         resultItem.setText(" " + result);

         os.close();
         reader.close();
         connection.close();
      }
      catch (Exception e)
      {
         resultItem.setLabel("Error:");
         resultItem.setText(e.toString());
      }
   }
}