Imports System.Web.Services
Imports System.Web.Services.Protocols

Imports System.Net
Imports System.Text.RegularExpressions

<WebService(Namespace:="http://xb.com/webservices/")> Public Class Service1
    Inherits System.Web.Services.WebService

    <WebMethod(), SoapRpcMethod()> Public Function getQuote(ByVal symbol As String) As String

        Dim hwreq As HttpWebRequest
        Dim hwres As HttpWebResponse
        Dim inStream As System.IO.Stream
        Dim strResponse As String
        Dim rgExp As Regex
        Dim m As Match

        m = rgExp.Match(symbol, "[a-zA-Z]{4}")

        If m.Success Then

            hwreq = CType(WebRequest.Create("http://finance.lycos.com/home/stocks/quotes.asp?symbols=" & symbol), HttpWebRequest)
            hwres = CType(hwreq.GetResponse(), HttpWebResponse)
            inStream = hwres.GetResponseStream()

            Try
                Do While True
                    strResponse = strResponse & Chr(inStream.ReadByte())
                Loop
            Catch ex As Exception
            End Try

            inStream.Close()

            Dim temp As String

            m = rgExp.Match(strResponse, "(?:Last.*)\d+\.\d+", RegexOptions.Singleline)

            If m.Success Then

                temp = m.Value()
                m = rgExp.Match(temp, "\d+\.\d+", RegexOptions.Singleline)

                If m.Success Then
                    getQuote = m.Value()
                    Exit Function

                End If

            End If

        End If

        Throw New Exception("Invalid stock symbol!")

    End Function

End Class