import javax.microedition.midlet.*;
import javax.microedition.io.*;
import javax.microedition.lcdui.*;

import java.io.InputStream;

public class client extends MIDlet implements CommandListener
{
   private Command cmdQuit = new Command("Quit", Command.EXIT, 2);
   private Display display;

   public client()
   {
      display = Display.getDisplay(this);
   }

   public void startApp()
   {
      makeContact();
   }

   private void makeContact()
   {
      StringBuffer b = new StringBuffer();
      HttpConnection c = null;
      TextBox t = null;

      try
      {
         long len = 0;
         int ch = 0;
         String strURL = "http://localhost/j2me.asp?ssno=343-81-6278";

         c = (HttpConnection)Connector.open(strURL);
         InputStream is = c.openInputStream();
         len = c.getLength();

         for (int i = 0; i < len; i ++)
         {
            if ((ch = is.read()) != -1)
            {
               if (ch <= ' ') ch = ' ';
               b.append((char) ch);
            }
         }

         is.close();
         c.close();

         t = new TextBox("Microsoft speaks!", b.toString(), b.length(), 0);
      }
      catch (Exception e)
      {
         System.out.println(e.toString());
      }

      t.addCommand(cmdQuit);
      display.setCurrent(t);
   }

   public void pauseApp()
   {
   }

   public void destroyApp(boolean unconditional)
   {
   }

   public void commandAction(Command c, Displayable s)
   {
      if (c == cmdQuit)
      {
         destroyApp(false);
         notifyDestroyed();
      }
   }
}