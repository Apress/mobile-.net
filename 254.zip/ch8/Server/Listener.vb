Imports System
Imports System.IO.Stream
Imports System.Net
Imports System.Net.Sockets
Imports System.Text
Imports System.Text.RegularExpressions
Imports System.Threading

Public Class Listener

    Public Sub run()

        Dim tcpl As TcpListener = New TcpListener(1973)
        Dim enc As ASCIIEncoding = New ASCIIEncoding()
        Dim app As Application

        tcpl.Start()

        Do Until False

            Dim sckt As Socket = tcpl.AcceptSocket()
            Dim btChar(0) As Byte

            Dim strSymbol As String = ""
            Dim strResponse As String = ""

            sckt.Receive(btChar, 1, 0)

            Do Until (btChar(0) = 13)
                app.DoEvents()
                strSymbol = strSymbol & enc.GetString(btChar)
                sckt.Receive(btChar, 1, 0)
            Loop

            Dim hwreq As HttpWebRequest
            Dim hwres As HttpWebResponse
            Dim inStream As System.IO.Stream

            hwreq = CType(WebRequest.Create("http://finance.lycos.com/" & _
                "home/stocks/quotes.asp?symbols=" & strSymbol), HttpWebRequest)
            hwres = CType(hwreq.GetResponse(), HttpWebResponse)
            inStream = hwres.GetResponseStream()

            Try
                Do While True
                    strResponse = strResponse & Chr(inStream.ReadByte())
                Loop
            Catch e As Exception
            End Try

            inStream.Close()

            Dim rgExp As Regex
            Dim m As Match
            Dim btPrice As Byte()

            m = rgExp.Match(strResponse, "\d+\.\d+", RegexOptions.Singleline)

            If m.Success Then
                btPrice = enc.GetBytes(m.Value())
            Else
                btPrice = enc.GetBytes("0.00")
            End If

            sckt.Send(btPrice, btPrice.Length, SocketFlags.None)

        Loop

    End Sub

End Class