Imports System.IO
Imports System.Text
Imports System.Net.Sockets

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblQuote As System.Windows.Forms.Label
    Friend WithEvents txtSymbol As System.Windows.Forms.TextBox
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.lblQuote = New System.Windows.Forms.Label()
        Me.txtSymbol = New System.Windows.Forms.TextBox()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblQuote
        '
        Me.lblQuote.Location = New System.Drawing.Point(80, 24)
        Me.lblQuote.Name = "lblQuote"
        Me.lblQuote.TabIndex = 0
        '
        'txtSymbol
        '
        Me.txtSymbol.Location = New System.Drawing.Point(88, 72)
        Me.txtSymbol.Name = "txtSymbol"
        Me.txtSymbol.TabIndex = 1
        Me.txtSymbol.Text = ""
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(104, 152)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.TabIndex = 2
        Me.btnSubmit.Text = "Get Quote"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(292, 266)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.btnSubmit, Me.txtSymbol, Me.lblQuote})
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click

        Dim app As Application
        Dim enc As ASCIIEncoding = New ASCIIEncoding()
        Dim btOut As Byte() = enc.GetBytes(txtSymbol.Text & Chr(13))
        Dim btIn As Byte

        Dim client As TcpClient = New TcpClient("localhost", 1973)
        Dim theStream As Stream = client.GetStream()

        lblQuote.Text = ""
        app.DoEvents()

        theStream.Write(btOut, 0, btOut.Length)
        theStream.Flush()

        Try
            Do Until False
                btIn = theStream.ReadByte()
                lblQuote.Text = lblQuote.Text & Chr(btIn)
            Loop
        Catch problem As Exception
        End Try

        client.Close()

        txtSymbol.Text = ""

    End Sub
End Class
